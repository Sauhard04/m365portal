export { SecurityService } from './security.service';
export { default } from './security.service';
