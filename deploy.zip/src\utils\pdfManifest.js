export const pdfManifest = [
    'Manually Add iPhone Devices Using a Mac.pdf'
    // Add more PDFs here as they are added to the docs folder
];
