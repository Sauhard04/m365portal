export { SharePointService } from './sharepoint.service';
export { default } from './sharepoint.service';
